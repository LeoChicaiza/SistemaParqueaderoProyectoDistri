# Auth Service

Microservice for handling user registration and authentication.