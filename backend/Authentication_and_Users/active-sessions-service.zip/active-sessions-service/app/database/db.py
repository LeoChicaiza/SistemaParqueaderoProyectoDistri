
# Simulación de base de datos de sesiones
sessions_db = {}

def init():
    global sessions_db
    sessions_db = {}
