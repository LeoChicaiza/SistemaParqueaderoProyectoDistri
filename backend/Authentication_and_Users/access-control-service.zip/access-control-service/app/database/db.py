
# Simulación de base de datos de roles en memoria
role_db = {}

def init():
    global role_db
    role_db = {}
