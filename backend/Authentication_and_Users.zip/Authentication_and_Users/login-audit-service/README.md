# Login Audit Service

Logs and retrieves user login attempts.