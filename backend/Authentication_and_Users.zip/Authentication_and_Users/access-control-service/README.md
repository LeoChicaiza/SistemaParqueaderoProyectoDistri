# Access Control Service

Handles role and permission management for users.