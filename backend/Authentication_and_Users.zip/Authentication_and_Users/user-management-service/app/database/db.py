
# Simulación de una base de datos en memoria
users_db = {}

def init():
    global users_db
    users_db = {}
