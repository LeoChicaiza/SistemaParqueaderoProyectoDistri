# Recovery Service

Handles password recovery and reset via token.