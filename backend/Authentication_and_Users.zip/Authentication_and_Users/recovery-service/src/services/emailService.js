exports.sendToken = async (username, token) => {
    console.log(`Sending recovery token to ${username}: ${token}`);
    // Integration with real email service can be added here.
};
